
//导航数据
var leftNavCode = [
    {
        title : "全部专题",
        id : "mytask1",
        pos : 0,
        child : [{title:"我发布的",tag:"task1"},{title:"我参与的",tag:"task2"},{title:"我关注的",tag:"task3"}]
    }

]

